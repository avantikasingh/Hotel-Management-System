package com.cg.hotelmanagement.dto;

import java.util.List;


public class HotelManagement {
	private List<?> customerList;
	private List<?> hotelList;
	private List<?> adminList;
	private List<?> bookingList;
	
	
	

}
