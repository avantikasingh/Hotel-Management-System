package com.cg.hotelmanagement.dto;

public class Admin {


}
