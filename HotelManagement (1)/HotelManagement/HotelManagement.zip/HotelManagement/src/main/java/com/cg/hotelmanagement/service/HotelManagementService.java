package com.cg.hotelmanagement.service;

import com.cg.hotelmanagement.dto.Admin;
import com.cg.hotelmanagement.dto.Booking;
import com.cg.hotelmanagement.dto.Customer;
import com.cg.hotelmanagement.dto.Hotel;

import java.util.List;

public interface HotelManagementService {

    public List<Customer> showCustomerList();

    public void addCustomer(Customer customer);

    public List<Hotel> showHotelList();

    public void addHotel(Hotel hotel);

    public void removeHotel(Hotel hotel);

    public Hotel updateHotel(Hotel hotel);

    public List<Admin> showAdminList();

    public List<Booking> showBookingList();

    public void addBooking(Booking booking);

}
