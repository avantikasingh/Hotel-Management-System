package com.cg.hotelmanagement.dao;

import com.cg.hotelmanagement.dto.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HotelManagementDaoImpl implements HotelManagementDao{

    private List<Customer> customerList = new ArrayList<>();
    private List<Hotel> hotelList = new ArrayList<>();
    private List<Admin> adminList = new ArrayList<>();
    private List<Booking> bookingList = new ArrayList<>();
    private Map<Integer, Integer> roomMap = new HashMap<>();

    public List<Customer> showCustomerList() {
        return customerList;
    }

    public void addCustomer(Customer customer) {
        this.customerList.add(customer);
    }

    public List<Hotel> showHotelList() {
        return hotelList;
    }

    public void addHotel(Hotel hotel){
        hotelList.add(hotel);
    }

    public void removeHotel(Hotel hotel){
        hotelList.remove(hotel);
    }

    public Hotel updateHotel(Hotel hotel){
        return hotel;
    }

    public List<Admin> showAdminList() {
        return adminList;
    }

    public List<Booking> showBookingList() {
        return bookingList;
    }

    public void addBooking(Booking booking){
        bookingList.add(booking);
    }

}
